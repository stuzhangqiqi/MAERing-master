import argparse
import numpy as np

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch_geometric.transforms as T
from tqdm.auto import tqdm

from torch.utils.data import DataLoader

# custom modules
from maskgae.utils import set_seed, tab_printer, get_dataset
from maskgae.model import MaskGAE, DegreeDecoder, EdgeDecoder, GNNEncoder, FeatureDecoder,GCL,Encoder
from maskgae.mask import MaskEdge, MaskPath
from torch_geometric.nn import GCNConv
from torch_geometric.utils import dropout_adj
from maskgae.eval import log_regression, MulticlassEvaluator, clustering,label_classification
import nni


def train_linkpred_test(model, splits, args, device="cpu"):
    optimizer = torch.optim.Adam(model.parameters(),
                                 lr=args.lr,
                                 weight_decay=args.weight_decay)

    best_valid = 0
    batch_size = args.batch_size

    train_data = splits['train'].to(device)
    valid_data = splits['valid'].to(device)
    test_data = splits['test'].to(device)

    for epoch in tqdm(range(1, 1 + args.epochs)):

        loss = model.train_step(train_data, optimizer,
                                alpha=args.alpha,
                                batch_size=args.batch_size)

        if epoch % args.eval_period == 0:
            valid_auc, valid_ap = model.test_step(valid_data,
                                                  valid_data.pos_edge_label_index,
                                                  valid_data.neg_edge_label_index,
                                                  batch_size=batch_size)
            if valid_auc > best_valid:
                best_valid = valid_auc
                best_epoch = epoch

                torch.save(model.state_dict(), args.save_path)

    model.load_state_dict(torch.load(args.save_path))
    test_auc, test_ap = model.test_step(test_data,
                                        test_data.pos_edge_label_index,
                                        test_data.neg_edge_label_index,
                                        batch_size=batch_size)
    return test_auc, test_ap

@torch.no_grad()
def test(data):
    GAEmodel.eval()
    z = GAEmodel(data.x, data.edge_index)

    acc = label_classification(z, data.y, ratio=0.1)
    nmi, ari, _ = clustering(z, data.y, 7)

    acc_mean = acc.get('F1Mi').get('mean')

    return acc_mean, nmi, ari


def adjust_learning_rate(optimizer, epoch):
    lr = args.lr * (args.lrdec_1 ** (epoch // args.lrdec_2))
    for param_group in optimizer.param_groups:
        param_group['lr'] = lr

def get_activation(name: str):
    activations = {
        'relu': F.relu,
        'hardtanh': F.hardtanh,
        'elu': F.elu,
        'leakyrelu': F.leaky_relu,
        'prelu': torch.nn.PReLU(),
        'rrelu': F.rrelu
    }

    return activations[name]

def filter_adj(row, col, mask):
    return row[mask], col[mask]

def dropout_edge(edge_index, edge_p):

    row, col = edge_index
    p = torch.zeros(edge_index.shape[1]).to(edge_index.device) + 1 - edge_p
    stay = torch.bernoulli(p).to(torch.bool)
    mask = ~stay
    row, col = filter_adj(row, col, stay)
    edge_index = torch.stack([row, col], dim=0)

    return edge_index.long(), mask


def dropedge_overlap(edge_index, edge_p, overlap):
    num_edges = edge_index.size(1)  # 获取边的总数
    mask_nodes = int(edge_p * num_edges)  # 计算掩码节点的数量
    overlap_nodes = int(mask_nodes * overlap)  # 计算重叠节点的数量

    # 生成重叠的边的索引
    overlap_edges = torch.randperm(num_edges)[:overlap_nodes]  # 随机排列所有边的索引，并选择前overlap_nodes个作为重叠的边

    # 生成两个掩码
    mask1 = torch.zeros(num_edges, dtype=torch.bool)  # 创建一个布尔型张量，表示第一个掩码，初始都是False
    mask2 = torch.zeros(num_edges, dtype=torch.bool)  # 创建一个布尔型张量，表示第二个掩码，初始都是False

    # 设置重叠的边
    mask1[overlap_edges] = True  # 将重叠边的索引对应的掩码位置设置为True
    mask2[overlap_edges] = True  # 同上，第二个掩码也设置重叠边为True

    # 计算非重叠的掩码节点数量
    non_overlap_nodes = mask_nodes - overlap_nodes

    # 生成非重叠的边的索引
    non_overlap_edges1 = torch.randperm(num_edges)[overlap_nodes:overlap_nodes + non_overlap_nodes // 2]
    non_overlap_edges2 = torch.randperm(num_edges)[
                         overlap_nodes + non_overlap_nodes // 2:overlap_nodes + non_overlap_nodes]

    # 设置非重叠的边
    mask1[non_overlap_edges1] = True
    mask2[non_overlap_edges2] = True

    # 使用掩码过滤边
    edge_index1 = edge_index[:, mask1]  # 使用第一个掩码过滤边，得到edge_index1
    edge_index2 = edge_index[:, mask2]  # 使用第二个掩码过滤边，得到edge_index2

    return edge_index1, edge_index2  # 返回两个过滤后的边索引张量


def drop_feature(x, drop_prob):
    drop_mask = torch.empty((x.size(1),), dtype=torch.float32, device=x.device).uniform_(0, 1) < drop_prob
    x = x.clone()
    x[:, drop_mask] = 0

    # # 效果不如上面，掩去全部特征效果不好
    # mask = torch.empty((x.size(0), ), dtype=torch.float32, device=x.device).uniform_(0, 1) < drop_prob
    # x = x.clone()
    # x[mask, :] = 0
    return x



def train_linkpred(model, splits, args, device="cpu"):
    print('Start Training (Link Prediction Pretext Training)...')
    optimizer = torch.optim.Adam(model.parameters(),
                                 lr=args.lr,
                                 weight_decay=args.weight_decay)

    best_valid = 0
    batch_size = args.batch_size

    train_data = splits['train'].to(device)
    valid_data = splits['valid'].to(device)
    test_data = splits['test'].to(device)

    model.reset_parameters()

    for epoch in tqdm(range(1, 1 + args.epochs)):
        # 只有边重构
        loss = model.pretrain_step(train_data, optimizer,
                                alpha=args.alpha,
                                batch_size=args.batch_size)

        if epoch % args.eval_period == 0:
            valid_auc, valid_ap = model.test_step(valid_data,
                                                  valid_data.pos_edge_label_index,
                                                  valid_data.neg_edge_label_index,
                                                  batch_size=batch_size)
            if valid_auc > best_valid:
                best_valid = valid_auc
                best_epoch = epoch
                torch.save(model.state_dict(), args.save_path)
                torch.save(model, args.dataset+'_'+'preteacher.pkl')

    model.load_state_dict(torch.load(args.save_path))
    test_auc, test_ap = model.test_step(test_data,
                                        test_data.pos_edge_label_index,
                                        test_data.neg_edge_label_index,
                                        batch_size=batch_size)

    print(f'Link Prediction Pretraining Results:\n'
          f'AUC: {test_auc:.2%}',
          f'AP: {test_ap:.2%}')
    return test_auc, test_ap


def train_nodeclas(model, data, args, device='cpu'):
    @torch.no_grad()
    def test(loader):
        clf.eval()
        logits = []
        labels = []
        for nodes in loader:
            logits.append(clf(embedding[nodes]))
            labels.append(y[nodes])
        logits = torch.cat(logits, dim=0).cpu()
        labels = torch.cat(labels, dim=0).cpu()
        logits = logits.argmax(1)
        return (logits == labels).float().mean().item()

    if args.dataset in {'arxiv', 'products', 'mag'}:
        batch_size = 4096
    else:
        batch_size = 512

    train_loader = DataLoader(data.train_mask.nonzero().squeeze(), batch_size=batch_size, shuffle=True)
    test_loader = DataLoader(data.test_mask.nonzero().squeeze(), batch_size=20000)
    val_loader = DataLoader(data.val_mask.nonzero().squeeze(), batch_size=20000)

    data = data.to(device)
    y = data.y.squeeze()
    embedding = model.encoder.get_embedding(data.x, data.edge_index)

    if args.l2_normalize:
        embedding = F.normalize(embedding, p=2, dim=1)  # Cora, Citeseer, Pubmed

    loss_fn = nn.CrossEntropyLoss()
    clf = nn.Linear(embedding.size(1), y.max().item() + 1).to(device)

    print('Start Training (Node Classification)...')
    results = []

    for run in range(1, args.runs + 1):
        nn.init.xavier_uniform_(clf.weight.data)
        nn.init.zeros_(clf.bias.data)
        optimizer = torch.optim.Adam(clf.parameters(),
                                     lr=0.01,
                                     weight_decay=args.nodeclas_weight_decay)

        best_val_metric = test_metric = 0
        for epoch in tqdm(range(1, 101), desc=f'Training on runs {run}...'):
            clf.train()
            for nodes in train_loader:
                optimizer.zero_grad()
                loss_fn(clf(embedding[nodes]), y[nodes]).backward()
                optimizer.step()

            val_metric, test_metric = test(val_loader), test(test_loader)
            if val_metric > best_val_metric:
                best_val_metric = val_metric
                best_test_metric = test_metric
        results.append(best_test_metric)
        print(f'Runs {run}: accuracy {best_test_metric:.2%}')

    print(f'Node Classification Results ({args.runs} runs):\n'
          f'Accuracy: {np.mean(results):.2%} ± {np.std(results):.2%}')


def kd_AE_CL(model_ae, GCLmodel, device, data, args):
    print('----------------GCL model start training--------------')
    optimizer = torch.optim.Adam(GCLmodel.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)
    evaluator = MulticlassEvaluator()
    soft_loss = nn.KLDivLoss(reduction='batchmean')
    temp1 = 3 # 蒸馏温度
    alpha1 = 80

    for epoch in range(1, args.num_epochs + 1):
        GCLmodel.train()
        optimizer.zero_grad()
        edge_index_1, edge_index_2 = dropedge_overlap(data.edge_index, args.drop_edge_rate, args.overlap)

        x_1 = drop_feature(data.x, args.drop_feature_rate_1)  # 3
        x_2 = drop_feature(data.x, args.drop_feature_rate_2)  # 4
        z1 = GCLmodel(x_1, edge_index_1)
        z2 = GCLmodel(x_2, edge_index_2)

        student_loss = GCLmodel.loss(z1, z2,
                                     batch_size=64 if args.dataset == 'Coauthor-Phy' or args.dataset == 'ogbn-arxiv' else None)

        student_preds = GCLmodel(data.x, data.edge_index)
        teacher_preds = model_ae(data.x, data.edge_index)

        distillation_loss = soft_loss(
            F.log_softmax(student_preds / temp1, dim=1),
            F.softmax(teacher_preds / temp1, dim=1)
        )  # soft_loss

        loss = student_loss + alpha1 * distillation_loss

        loss.backward()
        optimizer.step()
        cls_best_test = 0
        if epoch % 100 == 0:
            GCLmodel.eval()
            z = GCLmodel(data.x, data.edge_index)
            if args.dataset == 'Cora' or args.dataset == 'Citeseer' or  args.dataset == 'Pubmed': split = (data.train_mask, data.val_mask, data.test_mask)

            test_acc = log_regression(z, data, evaluator, split='preloaded', num_epochs=3000, preload_split=split)['acc']

            if test_acc > cls_best_test:
                cls_best_test = test_acc
                torch.save(GCLmodel, args.dataset+'_'+'teacher_cl.pkl')

            print(f'(E) | Epoch={epoch:04d}, avg_acc = {test_acc}')


def kd_CL_AE(model_cl, model_ae, device, data, args):
    print('--------------kdmodel start cl to ae--------------')
    # 教师模型
    model_cl.eval()
    # ae模型继续优化
    optimizer = torch.optim.Adam(model_ae.parameters(),  # 设置学习率和权重衰减参数
                                 lr=args.lr,
                                 weight_decay=args.weight_decay)
    evaluator = MulticlassEvaluator()
    # 蒸馏
    temp2 =11  # 蒸馏温度
    alpha2 = 100
    soft_loss = nn.KLDivLoss(reduction='batchmean')

    for epoch in range(1, args.num_epochs + 1):
        adjust_learning_rate(optimizer, epoch)

        model_ae.train()
        optimizer.zero_grad()
        recon_loss = model_ae.mae_recon_feature_loss(data)

        teacher_preds = GCLmodel(data.x, data.edge_index)
        student_preds = model_ae(data.x, data.edge_index)

        distillation_loss = soft_loss(
            F.log_softmax(student_preds / temp2, dim=1),
            F.softmax(teacher_preds / temp2, dim=1)
        )  # soft_loss

        loss = 1 * recon_loss + alpha2 * distillation_loss

        loss.backward()
        optimizer.step()

        cls_best_test = 0
        if epoch % 100 == 0:
            GCLmodel.eval()
            z = GCLmodel(data.x, data.edge_index)
            if args.dataset == 'Cora' or args.dataset == 'Citeseer' or args.dataset == 'Pubmed': split = (
            data.train_mask, data.val_mask, data.test_mask)

            test_acc = log_regression(z, data, evaluator, split='preloaded', num_epochs=3000, preload_split=split)['acc']

            if test_acc > cls_best_test:
                cls_best_test = test_acc

            print(f'(E) | Epoch={epoch:04d}, avg_acc = {cls_best_test}')
    print('--------------kdmodel end--------------')

if __name__=='__main__':
    # for i in range(1, 10):
        # for j in range(1, 10, 2):
            # print("i,j:",i,j)
        #     drop_edge_rate = i * 0.1


            # f = open( "Cora.txt", "a")
            # f.write("------------------------------------" + "\n")
            # f.write("temp1:" + str(temp1) + " " + "alpha1:" + str(alpha1) + " "  + "\n")
            # f.close()

            parser = argparse.ArgumentParser()
            parser.add_argument("--dataset", nargs="?", default="Cora", help="Datasets. (default: Cora)")
            parser.add_argument("--mask", nargs="?", default="Edge",
                                help="Masking stractegy, `Edge`, `Edge` or `None` (default: Path)")
            parser.add_argument('--seed', type=int, default=2022, help='Random seed for model and dataset. (default: 2022)')

            parser.add_argument("--layer", nargs="?", default="gcn", help="GNN layer, (default: gcn)")
            parser.add_argument("--encoder_activation", nargs="?", default="elu",
                                help="Activation function for GNN encoder, (default: elu)")
            parser.add_argument('--encoder_channels', type=int, default=128, help='Channels of GNN encoder layers. (default: 128)')
            parser.add_argument('--hidden_channels', type=int, default=512, help='Channels of hidden representation. (default: 64)')
            parser.add_argument('--decoder_channels', type=int, default=32, help='Channels of decoder layers. (default: 128)')
            parser.add_argument('--encoder_layers', type=int, default=2, help='Number of layers for encoder. (default: 2)')
            parser.add_argument('--decoder_layers', type=int, default=2, help='Number of layers for decoders. (default: 2)')
            parser.add_argument('--encoder_dropout', type=float, default=0.8, help='Dropout probability of encoder. (default: 0.8)')
            parser.add_argument('--decoder_dropout', type=float, default=0.2, help='Dropout probability of decoder. (default: 0.2)')
            parser.add_argument('--alpha', type=float, default=0., help='loss weight for degree prediction. (default: 0.)')

            parser.add_argument('--lr', type=float, default=0.01, help='Learning rate for training. (default: 0.01)')
            parser.add_argument('--weight_decay', type=float, default=5e-5,
                                help='weight_decay for link prediction training. (default: 5e-5)')
            parser.add_argument('--grad_norm', type=float, default=1.0, help='grad_norm for training. (default: 1.0.)')
            parser.add_argument('--batch_size', type=int, default=2 ** 16,
                                help='Number of batch size for link prediction training. (default: 2**16)')

            parser.add_argument("--start", nargs="?", default="node",
                                help="Which Type to sample starting nodes for random walks, (default: node)")
            parser.add_argument('--mask_edge', type=float, default=0.2, help='Mask ratio or sample ratio for MaskEdge/MaskPath')  #之前是0.7  这也是一个参数吗！！！用于训练和调试MAE

            parser.add_argument('--mask_feature', type=float, default=0.7, help='Mask ratio for feature')


            parser.add_argument('--bn', action='store_true',
                                help='Whether to use batch normalization for GNN encoder. (default: False)')
            parser.add_argument('--l2_normalize', action='store_true',
                                help='Whether to use l2 normalize output embedding. (default: False)')
            parser.add_argument('--nodeclas_weight_decay', type=float, default=1e-3,
                                help='weight_decay for node classification training. (default: 1e-3)')

            parser.add_argument('--epochs', type=int, default=500, help='Number of training epochs. (default: 500)')
            parser.add_argument('--runs', type=int, default=10, help='Number of runs. (default: 10)')
            parser.add_argument('--eval_period', type=int, default=30, help='(default: 30)')
            parser.add_argument("--save_path", nargs="?", default="MaskGAE-NodeClas.pt",
                                help="save path for model. (default: MaskGAE-NodeClas.pt)")
            parser.add_argument("--device", type=int, default=0)
            parser.add_argument('--full_data', action='store_true',
                                help='Whether to use full data for pretraining. (default: False)')

            # add
            parser.add_argument("--num_hidden", type=int, default=512)
            parser.add_argument("--num_proj_hidden", type=int, default=512)
            parser.add_argument("--activation", nargs="?", default='relu')
            parser.add_argument('--tau', type=float, default=0.4)
            parser.add_argument("--num_layers", type=int, default=2)
            parser.add_argument('--learning_rate', type=float, default=0.0005)
            parser.add_argument('--num_epochs', type=int, default=500, help='Number of training epochs.')
            parser.add_argument('--drop_edge_rate_1', type=float, default=0.1)
            parser.add_argument('--drop_edge_rate_2', type=float, default=0.4)
            # parser.add_argument('--drop_feature_rate', type=float, default=0.5)
            parser.add_argument('--drop_feature_rate_1', type=float, default=0.5)
            parser.add_argument('--drop_feature_rate_2', type=float, default=0.5)

            # 可调节参数
            parser.add_argument('--drop_edge_rate', type=float, default=0.5)
            parser.add_argument('--overlap', type=float, default=0.5)

            parser.add_argument('--lrdec_1', type=float, default=0.8)
            parser.add_argument('--lrdec_2', type=int, default=200)



            try:
                args = parser.parse_args()
                # print(tab_printer(args))
            except:
                parser.print_help()
                exit(0)

            set_seed(args.seed)

            # args.mask_feature = i * 0.1


            if args.device < 0:
                device = "cpu"
            else:
                device = f"cuda:{args.device}" if torch.cuda.is_available() else "cpu"

            transform = T.Compose([
                T.ToUndirected(),
                T.ToDevice(device),
            ])

            # (!IMPORTANT) Specify the path to your dataset directory ##############
            # root = '~/public_data/pyg_data' # my root directory
            root = 'data/'
            ########################################################################

            data = get_dataset(root, args.dataset, transform=transform)

            train_data, val_data, test_data = T.RandomLinkSplit(num_val=0.1, num_test=0.05,
                                                                is_undirected=True,
                                                                split_labels=True,
                                                                add_negative_train_samples=False)(data)
            if args.full_data:
                # Use full graph for pretraining
                splits = dict(train=data, valid=val_data, test=test_data)
            else:
                splits = dict(train=train_data, valid=val_data, test=test_data)

            if args.mask == 'Path':
                mask = MaskPath(p=args.mask_edge,
                                num_nodes=data.num_nodes,
                                start=args.start,
                                walk_length=args.encoder_layers + 1)
            elif args.mask == 'Edge':
                mask = MaskEdge(p=args.mask_edge)
            else:
                mask = None  # vanilla GAE

            encoder = GNNEncoder(data.num_features, args.encoder_channels, args.hidden_channels,
                                 num_layers=args.encoder_layers, dropout=args.encoder_dropout,
                                 bn=args.bn, layer=args.layer, activation=args.encoder_activation)

            edge_decoder = EdgeDecoder(args.hidden_channels, args.decoder_channels,
                                       num_layers=args.decoder_layers, dropout=args.decoder_dropout)

            feature_decoder = FeatureDecoder(data.num_features, args.encoder_channels, args.hidden_channels)

            GAEmodel = MaskGAE(encoder, edge_decoder, feature_decoder, data.num_nodes,data.num_features,mask, args.mask_feature).to(device)

            encoder = Encoder(data.num_features, args.num_hidden, get_activation(args.activation),
                              base_model=GCNConv, k=args.num_layers).to(device)
            # 模型初始化
            GCLmodel = GCL(encoder, args.num_hidden, args.num_proj_hidden, args.tau).to(device)
            GCLmodel = GCLmodel.to(device)

            train_linkpred(GAEmodel, splits, args, device=device)
            model_ae = torch.load(args.dataset+'_'+'preteacher.pkl')

            kd_AE_CL(model_ae, GCLmodel, device, data, args)
            model_cl = torch.load(args.dataset+'_'+'teacher_cl.pkl')

            kd_CL_AE(model_cl, GAEmodel, device, data, args)

            # 测试
            cls_results = []
            cls_best_test = 0
            auc_results = []
            ap_results = []
            for run in tqdm(range(1, 11)):
                acc, nmi, ari = test(data)
                # if acc.item() > cls_best_test:
                #     cls_best_test = acc.item()

                cls_results.append(acc)
                print(f'Runs {run}: accuracy {acc:.2%},nmi:{nmi:.4f}, ari: {ari:.4f}')
                print(f'Final result: acc: {acc:.4f}, nmi:{nmi:.4f}, ari: {ari:.4f}')
            print(f'Node Classification Results ({args.runs} runs):\n'
                  f'Accuracy: {np.mean(cls_results):.2%} ± {np.std(cls_results):.2%}')
            for run in range(1, args.runs + 1):
                test_auc, test_ap = train_linkpred_test(GAEmodel, splits, args, device=device)
                auc_results.append(test_auc)
                ap_results.append(test_ap)
                print(f'Runs {run} - AUC: {test_auc:.2%}', f'AP: {test_ap:.2%}')

            print(f'Link Prediction Results ({args.runs} runs):\n'
                  f'AUC: {np.mean(auc_results):.2%} ± {np.std(auc_results):.2%}',
                  f'AP: {np.mean(ap_results):.2%} ± {np.std(ap_results):.2%}',
                  )


            f = open(args.dataset + ".txt", "a")
            f.write(str(np.mean(cls_results)) + "\n")
            f.close()
